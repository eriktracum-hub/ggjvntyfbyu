# Šaha Studija — mācību projekts

Trīs lapu responsīva mājaslapa šaha komplektu pārdošanas idejai.

## Faili
- `index.html` — sākumlapa
- `produkti.html` — produktu katalogs
- `kontakti.html` — kontaktu lapa ar formas pārbaudi
- `style.css` — dizains un responsīvais izkārtojums
- `script.js` — mobilā izvēlne, gads un kontaktformas darbība

## Kā apskatīt
Atver `index.html` pārlūkā. Visām trim lapām jāatrodas vienā mapē.

## Publicēšana GitHub Pages
1. Izveido GitHub repository.
2. Augšupielādē visus piecus failus (un šo README).
3. Repository sadaļā Settings → Pages izvēlies `Deploy from a branch`, `main` un `/ (root)`.
4. Saglabā. Pēc publicēšanas GitHub parādīs publisko saiti.

## Svarīgi par kontaktformu
Forma pārbauda obligātos laukus un atver lietotāja e-pasta programmu ar sagatavotu ziņojumu uz `sveiki@sahastudija.lv`. Tā pati no sevis nenosūta datus serverim. Lai forma tiešām sūtītu e-pastus bez lietotāja e-pasta programmas, jāpieslēdz Formspree vai cita formas apstrādes servisa konts un jāievieto tā endpoint.
Produktu cenas un e-pasts ir demonstrācijas piemēri — nomaini tos pirms publiskas izmantošanas.
