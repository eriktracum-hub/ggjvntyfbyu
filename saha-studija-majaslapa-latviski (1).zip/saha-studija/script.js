// Kopējā navigācija un kontaktformas darbība visās lapās.
document.addEventListener("DOMContentLoaded", () => {
  const year = document.getElementById("year");
  if (year) year.textContent = new Date().getFullYear();

  const toggle = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".nav");
  if (toggle && nav) {
    toggle.addEventListener("click", () => {
      const isOpen = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(isOpen));
      toggle.textContent = isOpen ? "✕" : "☰";
    });
  }

  // Ja lietotājs produkta lapā izvēlas komplektu, tas tiek ielikts kontaktformas izvēlnē.
  const params = new URLSearchParams(window.location.search);
  const selectedProduct = params.get("produkts");
  const subject = document.getElementById("subject");
  if (selectedProduct && subject) {
    const option = [...subject.options].find(o => o.value.toLowerCase().startsWith(selectedProduct.toLowerCase()));
    if (option) subject.value = option.value;
  }

  const form = document.getElementById("contactForm");
  if (form) {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      if (!form.reportValidity()) return;
      const data = new FormData(form);
      const name = data.get("name");
      const email = data.get("email");
      const topic = data.get("subject");
      const message = data.get("message");
      const body = `Vārds: ${name}%0D%0AE-pasts: ${email}%0D%0ATēma: ${topic}%0D%0A%0D%0AZiņojums:%0D%0A${encodeURIComponent(message)}`;
      const mailto = `mailto:sveiki@sahastudija.lv?subject=${encodeURIComponent("Šaha Studija — " + topic)}&body=${body}`;
      document.getElementById("formNote").textContent = "Tiek atvērta e-pasta programma. Lai nosūtītu ziņojumu, apstiprini to savā e-pasta lietotnē.";
      window.location.href = mailto;
    });
  }
});